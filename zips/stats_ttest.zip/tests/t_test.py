OK_FORMAT = True

test = {   'name': 't_test',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> assert(t_test(normal(-0.3, 0.1, 100), normal(0.1, 0.3, 100))[0:4] == "True")\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
