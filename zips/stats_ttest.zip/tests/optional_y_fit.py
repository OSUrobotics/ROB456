OK_FORMAT = True

test = {   'name': 'optional_y_fit',
    'points': 0,
    'suites': [   {   'cases': [{'code': '>>> abs(fit_y_values_one_cluster(np.linspace(0, 1, 100), gaussian(np.linspace(0, 1, 100), 0.1, 2))[2]) < 0.001\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
