OK_FORMAT = True

test = {   'name': 'fit_x',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> abs(fit_x_values_one_cluster(normal(0.1, 0.2, 1000), gaussian(normal(0.1, 0.2, 1000), 0.1, 2))[0] - 0.1) < 0.1\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(fit_x_values_one_cluster(normal(0.1, 0.2, 1000), gaussian(normal(0.1, 0.2, 1000), 0.1, 2))[1] - 0.2) < 0.1\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
