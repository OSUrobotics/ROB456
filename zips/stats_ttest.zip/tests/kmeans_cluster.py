OK_FORMAT = True

test = {   'name': 'kmeans_cluster',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> assert(cluster_kmeans(uniform(0, 1, 100), 2)[0].shape[0] == 2)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
