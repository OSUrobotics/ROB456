OK_FORMAT = True

test = {   'name': 'hours_collaborators',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert(not "not filled out" in worked_with_names)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(not "not filled out" in websites)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(hours > 0)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
