OK_FORMAT = True

test = {   'name': 'syntax_check',
    'points': 4,
    'suites': [{'cases': [{'code': '>>> assert(test_particle_filter_syntax(b_print=False))\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
