OK_FORMAT = True

test = {   'name': 'kalman_filter',
    'points': 15,
    'suites': [{'cases': [{'code': '>>> assert(test_kalman_update(b_print=False))\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
