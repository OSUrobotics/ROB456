OK_FORMAT = True

test = {   'name': 'robotGT',
    'points': 5,
    'suites': [{'cases': [{'code': '>>> assert(test_continuous_move_functions(b_print=False))\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
