OK_FORMAT = True

test = {   'name': 'making_matrices',
    'points': 3,
    'suites': [{'cases': [{'code': '>>> assert(mt.test_matrices())\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
