OK_FORMAT = True

test = {   'name': 'check_matrices',
    'points': 3,
    'suites': [{'cases': [{'code': '>>> assert(mt.test_checks())\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
