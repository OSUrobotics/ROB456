OK_FORMAT = True

test = {   'name': 'bayes_filter',
    'points': 15,
    'suites': [   {   'cases': [   {'code': '>>> assert(test_bayes_filter_sensor_update(b_print=False))\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(test_move_one_direction(b_print=False))\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(test_move_update(b_print=False))\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
