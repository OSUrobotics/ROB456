OK_FORMAT = True

test = {   'name': 'robot_sensors',
    'points': 10,
    'suites': [{'cases': [{'code': '>>> assert(test_discrete_sensors(b_print=False))\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
