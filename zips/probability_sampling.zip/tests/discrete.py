OK_FORMAT = True

test = {   'name': 'discrete',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> assert(test_discrete(b_print=False))\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
