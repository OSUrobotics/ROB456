OK_FORMAT = True

test = {   'name': 'boolean_sample',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> assert(test_boolean(0.3, b_print=False))\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
