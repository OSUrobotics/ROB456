OK_FORMAT = True

test = {   'name': 'bins',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> assert(test_bins(b_print=False))\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
