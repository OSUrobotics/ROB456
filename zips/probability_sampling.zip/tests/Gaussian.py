OK_FORMAT = True

test = {   'name': 'Gaussian',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> assert(test_gaussian(b_print=False))\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
